import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import 'News_Screen.dart';
import 'Games_Screen.dart';
import 'Follow_Screen.dart';
import 'Widgets.dart';

class HomeScreen extends StatefulWidget {
  @override
  _HomeScreenState createState() => _HomeScreenState();
}

class _HomeScreenState extends State<HomeScreen> {
 
  int _indiceAtual = 0;
  final List<Widget> _telas = [
    NewsScreen(),
    GamesScreen(),
    FollowScreen()
  ];

  @override
  Widget build(BuildContext context) {
    return Scaffold(

      appBar: AppBar(

        title: Row(children:[
        Image.asset('assets/logo.png', height: 80, width: 80,), 
        Text('ALLGAMES', style: GoogleFonts.lato(
          textStyle: TextStyle(color: Colors.white, fontSize: 24, fontWeight: FontWeight.bold)
        ),),],

        mainAxisAlignment: MainAxisAlignment.end,
        ),
        backgroundColor: Theme.of(context).primaryColor, 
      ),

      drawer: NavDrawer(),

      bottomNavigationBar: BottomNavigationBar(
        currentIndex: _indiceAtual,
        onTap: onTabTapped,
        items: [
          BottomNavigationBarItem(
            icon: Icon(Icons.featured_play_list_rounded),
            label: ('Novidades')
          ),
          BottomNavigationBarItem(
            icon: Icon(Icons.sports_esports_rounded),
            label: ('Jogos')
          ),
          BottomNavigationBarItem(
            icon: Icon(Icons.star_rate_rounded),
            label: ('Seguindo')
          ),
        ],
      ),

      backgroundColor: Theme.of(context).backgroundColor,
      body: _telas[_indiceAtual],

    );
  }

  void onTabTapped(int index){
    setState(() {
      _indiceAtual = index;
    });
  }
}