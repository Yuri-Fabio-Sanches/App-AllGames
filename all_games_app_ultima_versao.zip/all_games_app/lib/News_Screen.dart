import 'package:all_games_app/model/noticia.dart';
import 'package:flutter/material.dart';
import 'model/noticia.dart';
import 'package:cloud_firestore/cloud_firestore.dart';

class NewsScreen extends StatefulWidget {
  @override
  _NewsScreenState createState() => _NewsScreenState();
}

class _NewsScreenState extends State<NewsScreen> {

  late CollectionReference noticias;
  
  @override
    void initState(){
    super.initState();
    noticias = FirebaseFirestore.instance.collection("noticias");
  }

  Widget exibirDocumento(item){

    Noticia noticia = Noticia.fromJson(item.data(), item.id);

    return Container(
      width: double.infinity,
      margin: EdgeInsets.fromLTRB(10,20,10,0),
      padding: EdgeInsets.fromLTRB(10, 20, 10, 20),
      decoration: BoxDecoration(border: Border.all(color: Theme.of(context).primaryColor)),

       child: Center(child: Column(children: <Widget> [

        Container(
          child: Column(children: [
            Text(noticia.titulo,style: TextStyle(fontSize: 20, fontWeight: FontWeight.bold), textAlign: TextAlign.center),
          ],)
        ),
        SizedBox(height: 20),
        Container(
          child: Column(children: [
            Text(noticia.corpo,style: TextStyle(fontSize: 20), textAlign: TextAlign.justify,),
          ],)
        ),
        SizedBox(height: 20),
        Row(
          mainAxisAlignment: MainAxisAlignment.spaceBetween,
          children: [
            ElevatedButton(
              style: ElevatedButton.styleFrom(primary: Theme.of(context).primaryColor),
              child: Text('Editar', style: TextStyle(color: Colors.white, fontSize: 18),),
              onPressed: (){
      
                Navigator.pushNamed(context, '/Publicar_Noticia', arguments: noticia.id);
              },
            ),
            ElevatedButton(
              style: ElevatedButton.styleFrom(primary: Theme.of(context).primaryColor),
              child: Text('Excluir', style: TextStyle(color: Colors.white, fontSize: 18),),
              onPressed: (){
  
                noticias.doc(noticia.id).delete();
              },
            ),
          ],
        ),

      ],),), 

    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(

      body: Container(
        padding: EdgeInsets.all(30),
        child: StreamBuilder<QuerySnapshot>(

          stream: noticias.snapshots(),

          builder: (context, snapshot){

            switch(snapshot.connectionState){

              case ConnectionState.none:
                return Center(child: Text('Erro ao conectar ao Firestore'));

              case ConnectionState.waiting:
                return Center(child: CircularProgressIndicator());

              default:
              
                final dados = snapshot.requireData;

                return ListView.builder(
                  itemCount: dados.size,
                  itemBuilder: (context,index){
                    return exibirDocumento(dados.docs[index]);
                  }
                );
            }
          }
        ),
      ),
    );
  }
}