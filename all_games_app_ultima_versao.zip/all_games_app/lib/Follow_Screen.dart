import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';

import 'model/times.dart';

class FollowScreen extends StatefulWidget {
  @override
  _FollowScreenState createState() => _FollowScreenState();
}

class _FollowScreenState extends State<FollowScreen> {

  late CollectionReference times;

  @override
  void initState(){
    super.initState();
    times = FirebaseFirestore.instance.collection("times");
  }

  Widget exibirDocumento(item){

    Time time = Time.fromJson(item.data(), item.id);

    return ListTile(
      title: Text(time.nome, style: GoogleFonts.lato(
          textStyle: TextStyle(color: Colors.black, fontSize: 24, fontWeight: FontWeight.bold))),
      subtitle: Text(time.estado, style: GoogleFonts.lato(
          textStyle: TextStyle(color: Colors.black, fontSize: 20, fontWeight: FontWeight.normal))),

      trailing: IconButton(
        icon: Icon(Icons.delete),
        onPressed: (){

          times.doc(time.id).delete();
        },
      ),

      onTap: (){
        Navigator.pushNamed(context, '/Publicar_Times', arguments: time.id);
      }

    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(

        body: Container(
        padding: EdgeInsets.all(30),
        child: StreamBuilder<QuerySnapshot>(

          stream: times.snapshots(),

          builder: (context, snapshot){

            switch(snapshot.connectionState){

              case ConnectionState.none:
                return Center(child: Text('Erro ao conectar ao Firestore'));

              case ConnectionState.waiting:
                return Center(child: CircularProgressIndicator());

              default:
                final dados = snapshot.requireData;

                return ListView.builder(
                  itemCount: dados.size,
                  itemBuilder: (context,index){
                    return exibirDocumento(dados.docs[index]);
                  }
                );
            }
          }
        ),
      ),
    );
  }
}