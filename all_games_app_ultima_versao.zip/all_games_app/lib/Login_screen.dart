import 'package:flutter/material.dart';
import 'package:firebase_auth/firebase_auth.dart';

class LoginScreen extends StatefulWidget {
  @override
  _LoginScreenState createState() => _LoginScreenState();
}

class _LoginScreenState extends State<LoginScreen> {

  var txtEmail = TextEditingController();
  var txtPassword = TextEditingController();
  bool isLoading = false;

  @override
  Widget build(BuildContext context) {
    return Scaffold(

      backgroundColor: Theme.of(context).backgroundColor,

     body: Container(
        padding: EdgeInsets.fromLTRB(50, 50, 50, 50),
        child: ListView(
          children: [
            Container(
              child: Column(children: [Image.asset('assets/logo.png')],),
            ),
            TextField(
              controller: txtEmail,
              style:
                  TextStyle(color: Colors.black, fontWeight: FontWeight.w300),
              decoration: InputDecoration(
                  prefixIcon: Icon(Icons.email, color: Theme.of(context).primaryColor,), labelText: 'Email', labelStyle: TextStyle(color: Theme.of(context).primaryColor,)),
            ),
            SizedBox(height: 20),
            TextField(
              obscureText: true,
              controller: txtPassword,
              style:
                  TextStyle(color: Colors.black, fontWeight: FontWeight.w300),
              decoration: InputDecoration(
                  prefixIcon: Icon(Icons.lock, color: Theme.of(context).primaryColor,), labelText: 'Senha', labelStyle: TextStyle(color: Theme.of(context).primaryColor,)),
            ),
            SizedBox(height: 40),
            Column(
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                Container(
                  padding: EdgeInsets.fromLTRB(0, 0, 0, 20),
                  width: 200,
                  height: 60,
                  child: ElevatedButton(
                    style: ElevatedButton.styleFrom(primary: Theme.of(context).primaryColor),
                    child: Text('Entrar', style: TextStyle(color: Colors.white, fontSize: 18),),
                    onPressed: () {

                    setState(() {
                      isLoading = true;
                    });

                    if(txtEmail.text == '' || txtPassword.text == ''){

                      caixaDialogo('Campos obrigatórios!', 'Preencha todos os campos corretamente!');

                    }else{

                      login(txtEmail.text, txtPassword.text);

                    }
                  },
                  ),
                ),
                Container(
                  padding: EdgeInsets.fromLTRB(0, 0, 0, 10),
                  width: 200,
                  height: 50,
                  child: ElevatedButton(
                    style: ElevatedButton.styleFrom(primary: Theme.of(context).primaryColor),
                    child: Text('Cadastrar', style: TextStyle(color: Colors.white, fontSize: 18),),
                    onPressed: () {
                      Navigator.pushNamed(context, '/Create_Account');
                    },
                  ),
                ),
              ],
            ),

              Container(

                child: IconButton(
                    icon: Icon (
                    Icons.info_outline_rounded,
                    color: Theme.of(context).primaryColor,
                  ),
                  onPressed: (){
                    setState(() {
                    Navigator.pushNamed(context, '/Info_Screen');
                });
                })

            ),
            SizedBox(height: 60),
          ],
        ),
      ),

    );
  }

  caixaDialogo(titulo, msg) {
    return showDialog(
        context: context,
        builder: (BuildContext context) {
          return AlertDialog(
            title: Text(titulo),
            content: Text(msg),
            actions: [
              TextButton(
                child: Text('Fechar'),
                onPressed: () {
                  Navigator.of(context).pop();
                },
              )
            ],
          );
        });
  }

  void login(email, password) {

    FirebaseAuth.instance.signInWithEmailAndPassword(
      email: email, password: password).then((resultado) {

        isLoading = false;
        Navigator.pushReplacementNamed(context, '/Home_Screen');

    }).catchError((erro){
      var mensagem = '';
      if (erro.code == 'user-not-found'){
        mensagem = 'ERRO: Usuário não encontrado';
      }else if (erro.code == 'wrong-password'){
        mensagem = 'ERRO: Senha incorreta';
      }else if (erro.code == 'invalid-email'){
        mensagem = 'ERRO: Email inválido';
      }else{
        mensagem = erro.message;
      }

      ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(
            content: Text('$mensagem'),
            duration: Duration(seconds:2)
          )
      );

    });

  }

}

  
