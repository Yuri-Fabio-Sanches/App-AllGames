import 'package:all_games_app/Create_Account.dart';
import 'package:flutter/material.dart';
import 'package:splashscreen/splashscreen.dart';
import 'Login_screen.dart';
import 'Home_Screen.dart';
import 'Create_Account.dart';
import 'Info_Screen.dart';
import 'Publicar_Noticia.dart';
import 'package:firebase_core/firebase_core.dart';
import 'Publicar_Times.dart';
import 'Publicar_Jogos.dart';

Future<void> main() async {

  WidgetsFlutterBinding.ensureInitialized();
  await Firebase.initializeApp();

  runApp(MyApp());

} 
 
class MyApp extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      title: 'Splash Screen',
      theme: ThemeData(
      primaryColor: Colors.deepPurple[600],
      backgroundColor: Colors.white,
      fontFamily: 'Roboto',
      textTheme: TextTheme(
          headline1: TextStyle(fontSize: 18, color: Colors.white),),
    ),
      initialRoute: '/Splash_Screen',
      routes: {
        '/Splash_Screen': (context) => MyHomePage(),
        '/Login_Screen': (context) => LoginScreen(),
        '/Home_Screen': (context) => HomeScreen(),
        '/Create_Account': (context) => CreateAccount(),
        '/Info_Screen': (context) => InfoScreen(),
        '/Publicar_Noticia': (context) => PublicarNoticia(),
        '/Publicar_Jogos': (context) => PublicarJogos(),
        '/Publicar_Times': (context) => PublicarTimes()
      },
    );
  }
}

class MyHomePage extends StatefulWidget {

  @override
  _MyHomePageState createState() => _MyHomePageState();
}

class _MyHomePageState extends State<MyHomePage> {
  @override
  Widget build(BuildContext context) {
    return _introScreen();
  }
}

Widget _introScreen() {
  return Stack(
    children: <Widget>[
      SplashScreen(
        seconds: 3,
        backgroundColor: Colors.deepPurple[600],
        navigateAfterSeconds: LoginScreen(),
        loaderColor: Colors.transparent,
      ),
      Container(
        decoration: BoxDecoration(
          image: DecorationImage(
            image: AssetImage("assets/logo.png"),
            fit: BoxFit.none,
          ),
        ),
      ),
    ],
  );
}