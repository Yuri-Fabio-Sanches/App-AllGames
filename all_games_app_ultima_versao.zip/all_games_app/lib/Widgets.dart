import 'package:firebase_auth/firebase_auth.dart';
import 'package:flutter/material.dart';

 class NavDrawer extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Drawer(
      child: ListView(
        padding: EdgeInsets.zero,
        children: <Widget>[
          new UserAccountsDrawerHeader(
            accountName : new Text('Yuri Fabio Sanches'),
            accountEmail: new Text('Yuriusp2011@hotmail.com'),
            currentAccountPicture: new CircleAvatar(backgroundImage: AssetImage('assets/yuri_dev.jpg'),
              
            ),
          ),
          ListTile(
            leading: Icon(Icons.account_circle_outlined),
            title: Text('Perfil'),
            onTap: () => {},
          ),
          ListTile(
            leading: Icon(Icons.file_present_outlined),
            title: Text('Publicar notícias'),
            onTap: () => {Navigator.pushReplacementNamed(context, '/Publicar_Noticia')},
          ),
          ListTile(
            leading: Icon(Icons.games_outlined),
            title: Text('Publicar jogos'),
            onTap: () => {Navigator.pushReplacementNamed(context, '/Publicar_Jogos')},
          ),
          ListTile(
            leading: Icon(Icons.shield_outlined),
            title: Text('Publicar times'),
            onTap: () => {Navigator.pushReplacementNamed(context, '/Publicar_Times')},
          ),
          ListTile(
            leading: Icon(Icons.settings),
            title: Text('Configurações'),
            onTap: () => {Navigator.of(context).pop()},
          ),
          ListTile(
            leading: Icon(Icons.exit_to_app),
            title: Text('Sair'),
            onTap: () => { FirebaseAuth.instance.signOut(),
                  Navigator.pushReplacementNamed(context, '/Login_Screen')},
          ),
        ],
      ),
    );
  }
}