class Noticia{

  late String id;
  late String titulo;
  late String corpo;

  Noticia(this.id, this.titulo, this.corpo);

  Noticia.fromJson( Map<String,dynamic> mapa, String id){
    this.id = id;
    this.titulo = mapa['titulo'];
    this.corpo = mapa['corpo'];
  }

  Map<String, dynamic> toJSon(){
    return{
      'id'        :this.id,
      'titulo'    :this.titulo,
      'corpo'     :this.corpo,
    };
  }
}