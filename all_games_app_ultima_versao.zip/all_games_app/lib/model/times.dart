class Time{

  late String id;
  late String nome;
  late String estado;

  Time(this.id, this.nome);

  Time.fromJson( Map<String,dynamic> mapa, String id){
    this.id = id;
    this.nome = mapa['nome'];
    this.estado = mapa['estado'];
  }

  Map<String, dynamic> toJSon(){
    return{
      'id'      :this.id,
      'nome'    :this.nome,
      'estado'  :this.estado,

    };
  }
}