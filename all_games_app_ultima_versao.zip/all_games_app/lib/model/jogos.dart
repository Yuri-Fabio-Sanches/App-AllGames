class Jogo{

  late String id;
  late String nome;
  late String estado;

  Jogo(this.id, this.nome);

  Jogo.fromJson( Map<String,dynamic> mapa, String id){
    this.id = id;
    this.nome = mapa['nome'];
    this.estado = mapa['estado'];
  }

  Map<String, dynamic> toJSon(){
    return{
      'id'      :this.id,
      'nome'    :this.nome,
      'estado'  :this.estado,
    };
  }
}