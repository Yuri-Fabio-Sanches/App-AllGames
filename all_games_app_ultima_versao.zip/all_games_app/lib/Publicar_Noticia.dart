import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';

class PublicarNoticia extends StatefulWidget {
  const PublicarNoticia({ Key? key }) : super(key: key);

  @override
  _PublicarNoticiaState createState() => _PublicarNoticiaState();
}

class _PublicarNoticiaState extends State<PublicarNoticia> {

  TextEditingController txtTitulo = TextEditingController();
  TextEditingController txtCorpo = TextEditingController();


  void getDocumentById(String id) async{
    await FirebaseFirestore.instance
      .collection('noticias').doc(id).get()
      .then((resultado) {
        txtTitulo.text = resultado.get('titulo');
        txtCorpo.text = resultado.get('corpo');
      });
  }

  @override
  Widget build(BuildContext context) {

    var id = ModalRoute.of(context)?.settings.arguments;

    if ( id != null){
      if (txtTitulo.text == '' && txtCorpo.text == ''){
        getDocumentById(id.toString());
      }
    }

    return Scaffold(

       appBar: AppBar(
        title:Row(children:[
        Image.asset('assets/logo.png', height: 80, width: 80,), 
        Text('ALLGAMES', style: GoogleFonts.lato(
          textStyle: TextStyle(color: Colors.white, fontSize: 24, fontWeight: FontWeight.bold)
        ),),],

        mainAxisAlignment: MainAxisAlignment.center),

        backgroundColor: Theme.of(context).primaryColor,

        automaticallyImplyLeading: false,

        actions: [
          IconButton(
            icon: Icon (
              Icons.close,
              color: Colors.white,
            ),
            onPressed: (){
              setState(() {
                Navigator.pushNamed(context, '/Home_Screen');
              });
            } )
        ],
      ),

      body: Column(
        children: [
          
          Container(
            alignment: Alignment.center,
            padding: EdgeInsets.fromLTRB(0, 30, 0, 0),
            child: Text('Título da notícia', style: GoogleFonts.lato(
              textStyle: TextStyle(color: Theme.of(context).primaryColor, fontSize: 24, fontWeight: FontWeight.bold)),),
          ),
          SizedBox(height: 20),
          Container(
            alignment: Alignment.center,
            padding: EdgeInsets.fromLTRB(50, 0, 50, 0),
            child: TextField(
              controller: txtTitulo,
              style:
                  TextStyle(color: Colors.black, fontWeight: FontWeight.w300),
              ),
          ),
          SizedBox(height: 20),
          Container(
            alignment: Alignment.center,
            padding: EdgeInsets.fromLTRB(0, 30, 0, 0),
            child: Text('Corpo da notícia', style: GoogleFonts.lato(
              textStyle: TextStyle(color: Theme.of(context).primaryColor, fontSize: 24, fontWeight: FontWeight.bold)),),
          ),
          SizedBox(height: 20),
          Container(
              alignment: Alignment.center,
              padding: EdgeInsets.fromLTRB(50, 0, 50, 0),
              child: TextField(
                keyboardType: TextInputType.multiline,
                maxLines: null,
                controller: txtCorpo,
                style:
                    TextStyle(color: Colors.black, fontWeight: FontWeight.w300),
              ),
            ),
          SizedBox(height: 20),
          Container(
            alignment: Alignment.center,
            padding: EdgeInsets.fromLTRB(0, 0, 0, 20),
            width: 200,
            height: 60,
            child: ElevatedButton(
              style: ElevatedButton.styleFrom(primary: Theme.of(context).primaryColor),
              child: Text('Salvar', style: TextStyle(color: Colors.white, fontSize: 18),),
              onPressed: () {

                var db = FirebaseFirestore.instance;

                if(txtTitulo.text == '' || txtCorpo.text == ''){

                caixaDialogo('Campos obrigatórios!', 'Preencha todos os campos corretamente!');

                }else if (id == null){

                db.collection('noticias').add({
                  'titulo': txtTitulo.text,
                  'corpo': txtCorpo.text,
                });

                }else{
                  db.collection('noticias').doc(id.toString())
                    .update(
                      {
                        'titulo' : txtTitulo.text,
                        'corpo': txtCorpo.text,
                     }
                  );
                }
              },
            ),
          ),
        ],

      ),
      
    );
  }

  caixaDialogo(titulo, msg) {
    return showDialog(
        context: context,
        builder: (BuildContext context) {
          return AlertDialog(
            title: Text(titulo),
            content: Text(msg),
            actions: [
              TextButton(
                child: Text('Fechar'),
                onPressed: () {
                  Navigator.of(context).pop();
                },
              )
            ],
          );
        });
  }
}