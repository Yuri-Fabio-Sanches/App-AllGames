import 'package:flutter/material.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_auth/firebase_auth.dart';

class CreateAccount extends StatefulWidget {
  @override
  _CreateAccountState createState() => _CreateAccountState();
}

class _CreateAccountState extends State<CreateAccount> {

  var txtNome = TextEditingController();
  var txtPassword = TextEditingController();
  var txtEmail = TextEditingController();
  var txtTelefone = TextEditingController();
  var txtCpf = TextEditingController();
  var txtPasswordConfirmation = TextEditingController();

  @override
  Widget build(BuildContext context) {
    return Scaffold(

      backgroundColor: Theme.of(context).backgroundColor,

body: Container(
        padding: EdgeInsets.fromLTRB(50, 50, 50, 50),
        child: ListView(
          children: [
            TextField(
              keyboardType: TextInputType.name,
              controller: txtNome,
              style:
                  TextStyle(color: Colors.black, fontWeight: FontWeight.w300),
              decoration: InputDecoration(
                prefixIcon: Icon(Icons.person, color: Theme.of(context).primaryColor,), labelText: 'Nome completo', labelStyle: TextStyle(color: Theme.of(context).primaryColor,)),
            ),
            SizedBox(height: 20),
            TextField(
              keyboardType: TextInputType.number,
              controller: txtCpf,
              style:
                  TextStyle(color: Colors.black, fontWeight: FontWeight.w300),
              decoration: InputDecoration(
                  prefixIcon: Icon(Icons.assignment, color: Theme.of(context).primaryColor,), labelText: 'Cpf', labelStyle: TextStyle(color: Theme.of(context).primaryColor,)),
            ),
            SizedBox(height: 20),
            TextField(
              keyboardType: TextInputType.number,
              controller: txtTelefone,
              style:
                  TextStyle(color: Colors.black, fontWeight: FontWeight.w300),
              decoration: InputDecoration(
                  prefixIcon: Icon(Icons.phone, color :Theme.of(context).primaryColor,), labelText: 'Telefone', labelStyle: TextStyle(color: Theme.of(context).primaryColor,)),
            ),
            TextField(
              controller: txtEmail,
              style:
                  TextStyle(color: Colors.black, fontWeight: FontWeight.w300),
              decoration: InputDecoration(
                  prefixIcon: Icon(Icons.email, color: Theme.of(context).primaryColor,), labelText: 'Email', labelStyle: TextStyle(color: Theme.of(context).primaryColor,)),
            ),
            SizedBox(height: 20),
            TextField(
              obscureText: true,
              controller: txtPassword,
              style:
                  TextStyle(color: Colors.black, fontWeight: FontWeight.w300),
              decoration: InputDecoration(
                  prefixIcon: Icon(Icons.lock, color: Theme.of(context).primaryColor,), labelText: 'Senha', labelStyle: TextStyle(color: Theme.of(context).primaryColor,)),
            ),
            SizedBox(height: 20),
            TextField(
              obscureText: true,
              controller: txtPasswordConfirmation,
              style:
                  TextStyle(color: Colors.black, fontWeight: FontWeight.w300),
              decoration: InputDecoration(
                  prefixIcon: Icon(Icons.lock, color: Theme.of(context).primaryColor,), labelText: 'Confirmar senha', labelStyle: TextStyle(color: Theme.of(context).primaryColor,)),
            ),
            SizedBox(height: 40),
            Column(
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                Container(
                  padding: EdgeInsets.fromLTRB(0, 0, 0, 20),
                  width: 200,
                  height: 60,
                  child: ElevatedButton(
                    style: ElevatedButton.styleFrom(primary: Theme.of(context).primaryColor),
                    child: Text('criar', style: TextStyle(color: Colors.white, fontSize: 18),),
                    onPressed: () {

                      if(txtNome.text == '' || txtPassword.text == '' || txtEmail.text == '' || txtPasswordConfirmation.text == '' || txtCpf.text == '' || txtTelefone.text == ''){

                        caixaDialogo('Campos obrigatórios!', 'Preencha todos os campos corretamente!');

                      }else if (txtPassword.text != txtPasswordConfirmation.text ) {

                        caixaDialogo('Senha de confirmação incorreta!', 'Sua senha de confirmação não é a mesma que a senha escolhida!');

                      }else{

                        criarConta(txtNome.text, txtEmail.text, txtPassword.text, txtCpf.text, txtTelefone.text);

                      }
                      
                    },
                  ),
                ),
                Container(
                  width: 200,
                  height: 40,
                  child: ElevatedButton(
                    style: ElevatedButton.styleFrom(primary: Theme.of(context).primaryColor),
                    child: Text('cancelar', style: TextStyle(color: Colors.white, fontSize: 18),),
                    onPressed: () {
                      Navigator.pop(context);
                    },
                  ),
                ),
              ],
            ),
            SizedBox(height: 60),
          ],
        ),
      ),

    );
  }

  caixaDialogo(titulo, msg) {
    return showDialog(
        context: context,
        builder: (BuildContext context) {
          return AlertDialog(
            title: Text(titulo),
            content: Text(msg),
            actions: [
              TextButton(
                child: Text('Fechar'),
                onPressed: () {
                  Navigator.of(context).pop();
                },
              )
            ],
          );
        });
  }

  void criarConta(nome, email, senha, cpf, telefone) {

    FirebaseAuth fa = FirebaseAuth.instance;
    fa.createUserWithEmailAndPassword(
      email: email, password: senha).then((resultado) {
        //armazenar dados adicionais no Firestore
        var db = FirebaseFirestore.instance;
        db.collection('usuarios').doc(resultado.user!.uid).set(
          {
            'nome'  : nome,
            'email' : email,
            'cpf'  : cpf,
            'telefone' : telefone,
          }
        ).then((valor){
          ScaffoldMessenger.of(context).showSnackBar(
            SnackBar(
              content: Text('Usuário criado com sucesso.'),
              duration: Duration(seconds:2)
            )
          );
          Navigator.pop(context);
        });
    }).catchError((erro){
      if (erro.code == 'email-already-in-use'){
        ScaffoldMessenger.of(context).showSnackBar(
            SnackBar(
              content: Text('ERRO: O email informado já está em uso.'),
              duration: Duration(seconds:2)
            )
          );
      }else{
        ScaffoldMessenger.of(context).showSnackBar(
            SnackBar(
              content: Text('ERRO: ${erro.message}'),
              duration: Duration(seconds:2)
            )
          );
      }
    });
    
  }

}