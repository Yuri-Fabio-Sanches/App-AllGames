import 'package:flutter/material.dart';
import 'Widgets.dart';

class NewsScreen extends StatefulWidget {
  @override
  _NewsScreenState createState() => _NewsScreenState();
}

class _NewsScreenState extends State<NewsScreen> {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      
     body: SingleChildScrollView(
        child: Column(children: [

          NewsWidget('PS5 vende mais rápido que PS4 e faz Sony bater recorde de lucro anual', 'ps5.png', '/News_Ps5'),
          NewsWidget('Torneio mundial inédito aos universitários anuncia semifinalistas brasileiros', 'esports.png', '/News_Esports'),
          NewsWidget('Xbox tem promoção de FIFA 21 e mais jogos com até 85% de desconto', 'xbox.png', '/News_Xbox'),
          NewsWidget('PS Plus de maio tem Wreckfest no PS5 e Battlefield 5 no PS4', 'promocao.png', '/News_Promotion'),

        ]
          ),
      ),

    );
  }
}