import 'package:flutter/material.dart';

class FollowScreen extends StatefulWidget {
  @override
  _FollowScreenState createState() => _FollowScreenState();
}

class _FollowScreenState extends State<FollowScreen> {

  var timesSeguindo = [];
  var timesNaoSeguindo = [];
  var logosSeguindoTimes = [];
  var logosNaoSeguindoTimes = [];

  // var txttimesSeguindo = TextEditingController();
  // var txttimesNaoSeguindo = TextEditingController();

  @override
  void initState(){
    logosSeguindoTimes.add(AssetImage("assets/Fnatic.png"),);
    logosSeguindoTimes.add(AssetImage("assets/G2.jpg"),);
    logosSeguindoTimes.add(AssetImage("assets/Immortals.png"),);
    logosSeguindoTimes.add(AssetImage("assets/Flamengo.png"),);
    logosSeguindoTimes.add(AssetImage("assets/RedCanids.png"),);

    logosNaoSeguindoTimes.add(AssetImage("assets/BlackDragons.png"),);
    logosNaoSeguindoTimes.add(AssetImage("assets/MIBR.png"),);
    logosNaoSeguindoTimes.add(AssetImage("assets/Liquid.png"),);
    logosNaoSeguindoTimes.add(AssetImage("assets/Cloud9.png"),);
    logosNaoSeguindoTimes.add(AssetImage("assets/Pain.png"),);

    timesSeguindo.add("Fnatic");
    timesSeguindo.add("G2 Esports");
    timesSeguindo.add("Immortals");
    timesSeguindo.add("Flamengo eSports");
    timesSeguindo.add("Red Canids");

    timesNaoSeguindo.add("Black Dragons");
    timesNaoSeguindo.add("MIBR");
    timesNaoSeguindo.add("Team Liquid");
    timesNaoSeguindo.add("Cloud 9");
    timesNaoSeguindo.add("Pain Gaming");
    super.initState();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Container(
        padding: EdgeInsets.all(40),

        child:Column(
          children: [

            Container(
              padding: EdgeInsets.fromLTRB(0, 0, 0, 10),
              child: Column(children: [Text('Meus times',style: TextStyle(fontSize: 20, fontWeight: FontWeight.bold, color: Colors.deepPurple[600]), textAlign: TextAlign.center)],),
            ),

            SizedBox(height: 30),

            Expanded(
              child: ListView.separated(

                //aparência item
                itemBuilder: (context, index){
                  return Container(
                    child: ListTile(
                      leading: CircleAvatar(backgroundImage: logosSeguindoTimes[index], backgroundColor: Colors.white,),
                      title: Text(timesSeguindo[index]),
                      subtitle: Text('Seguindo'),
                      trailing: Icon (Icons.check_circle_outline, color: Colors.green), 
                      )
                    );
                },

                //aprencia separador
                separatorBuilder: (context, index){
                  return Divider(
                    color: Theme.of(context).primaryColor,
                    thickness: 1,
                  );
                },

                //quantidade itens
                itemCount: timesSeguindo.length,

              )
            ),

            Container(
              padding: EdgeInsets.fromLTRB(0, 40, 0, 30),
              child: Column(children: [Text('Seguir novos times',style: TextStyle(fontSize: 20, fontWeight: FontWeight.bold, color: Colors.deepPurple[600]), textAlign: TextAlign.center)],),
            ),

            Expanded(
              child: ListView.separated(

                //aparência item
                itemBuilder: (context, index){
                  return Container(
                    child: ListTile(
                      leading: CircleAvatar(backgroundImage: logosNaoSeguindoTimes[index], backgroundColor: Colors.white,),
                      title: Text(timesNaoSeguindo[index]),
                      subtitle: Text('Não seguindo'),
                      trailing: Icon (Icons.highlight_off, color: Colors.red), 
                      )
                    );
                },

                //aprencia separador
                separatorBuilder: (context, index){
                  return Divider(
                    color: Theme.of(context).primaryColor,
                    thickness: 1,
                  );
                },

                //quantidade itens
                itemCount: timesNaoSeguindo.length,

              )
            )

          ],
        ),
      ),
    );
  }
}