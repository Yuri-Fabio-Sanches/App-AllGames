import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import 'News_Screen.dart';
import 'Games_Screen.dart';
import 'Follow_Screen.dart';

class HomeScreen extends StatefulWidget {
  @override
  _HomeScreenState createState() => _HomeScreenState();
}

class _HomeScreenState extends State<HomeScreen> {
 
  int _indiceAtual = 0;
  final List<Widget> _telas = [
    NewsScreen(),
    GamesScreen(),
    FollowScreen()
  ];

  @override
  Widget build(BuildContext context) {
    return Scaffold(

      appBar: AppBar(
        title: Text('ALLGAMES',
        style: GoogleFonts.lato(
          textStyle: TextStyle(color: Colors.white, fontSize: 24, fontWeight: FontWeight.bold)
        ),
        ),
        backgroundColor: Theme.of(context).primaryColor,
        automaticallyImplyLeading: false,
        actions: [
          IconButton(
            icon: Icon (
              Icons.info_outline_rounded,
              color: Colors.white,
            ),
            onPressed: (){
              setState(() {
                Navigator.pushNamed(context, '/Info_Screen');
              });
            } )
        ],
        leading: Image.asset('assets/logo.png'), 
      ),

      bottomNavigationBar: BottomNavigationBar(
        currentIndex: _indiceAtual,
        onTap: onTabTapped,
        items: [
          BottomNavigationBarItem(
            icon: Icon(Icons.featured_play_list_rounded),
            label: ('Novidades')
          ),
          BottomNavigationBarItem(
            icon: Icon(Icons.sports_esports_rounded),
            label: ('Jogos')
          ),
          BottomNavigationBarItem(
            icon: Icon(Icons.star_rate_rounded),
            label: ('Seguindo')
          ),
        ],
      ),

      backgroundColor: Theme.of(context).backgroundColor,
      body: _telas[_indiceAtual],

    );
  }

  void onTabTapped(int index){
    setState(() {
      _indiceAtual = index;
    });
  }
}