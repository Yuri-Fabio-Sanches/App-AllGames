import 'package:flutter/material.dart';
import 'package:flutter/rendering.dart';
import 'package:google_fonts/google_fonts.dart';

class InfoScreen extends StatefulWidget {
  @override
  _InfoScreenState createState() => _InfoScreenState();
}

class _InfoScreenState extends State<InfoScreen> {

  var fotosDev = [];

  @override

  void initState(){

    fotosDev.add(AssetImage("assets/vini_dev.jpg"),);
    fotosDev.add(AssetImage("assets/yuri_dev.jpg"),);

    super.initState();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(

      appBar: AppBar(
        title: Text('ALLGAMES',
        style: GoogleFonts.lato(
          textStyle: TextStyle(color: Colors.white, fontSize: 24, fontWeight: FontWeight.bold)
        ),
        ),
        backgroundColor: Theme.of(context).primaryColor,
        automaticallyImplyLeading: false,
        actions: [
          IconButton(
            icon: Icon (
              Icons.close,
              color: Colors.white,
            ),
            onPressed: (){
              setState(() {
                Navigator.pop(context);
              });
            } )
        ],
        leading: Image.asset('assets/logo.png'), 
      ),

      body: Container(
        padding: EdgeInsets.fromLTRB(40, 20, 40, 20),
        child: Column(
          children: [

            Container(child: Column(children: [Text('Desenvolvedores',style: TextStyle(fontSize: 24, fontWeight: FontWeight.bold, color: Colors.deepPurple[600]), textAlign: TextAlign.center)],),),
            
            Container(child: Column(children: [

              Row(children: [
                Container(
                  margin: EdgeInsets.fromLTRB(0, 20, 0, 10),
                  height: 200,
                  width: 200,
                  child: Center(child: Image.asset('assets/vini_dev.jpeg'),),
                ),

                Container(
                  margin: EdgeInsets.fromLTRB(0, 20, 0, 10),
                  height: 200,
                  width: 200,
                  child: Center(child: Image.asset('assets/yuri_dev.jpg'),),
                ),
              ],)
            ],),),

            Row(children: [

              Container(
                margin: EdgeInsets.fromLTRB(50, 0, 0, 40),
                child: Text('Vinicius Lupato', style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold, color: Colors.deepPurple[600]),),
              ),

              Container(
                margin: EdgeInsets.fromLTRB(60, 0, 0, 40),
                child: Text('Yuri Fabio Sanches', style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold, color: Colors.deepPurple[600])),
              ),

            ],),

            Container(child: Column(children: [Text('Sobre o APP \n',style: TextStyle(fontSize: 24, fontWeight: FontWeight.bold, color: Colors.deepPurple[600]), textAlign: TextAlign.center)],),),

            Container(child: Column(children: [Text('     O aplicativo mobile All Games esta voltado para uma oportunidade de mercado que visa agrupar todas as principais notícias e dados relacionados ao nicho de produtos, jogos eletrônicos e eSports, simplificando o acesso a informações anteriormente espalhadas em diversos meios informacionais. \n\n     O objetivo do apicativo é permitir que os usuários consigam ter acesso da maneira mais simples a todas as informações e notícias sobre o mundo de produtos, jogos eletrônicos eSports.',style: TextStyle(fontSize: 20, fontWeight: FontWeight.normal), textAlign: TextAlign.justify)],),),


          ],
        ),

      ),

    );
      
  }
}
