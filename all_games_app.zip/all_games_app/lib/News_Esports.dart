import 'package:all_games_app/Widgets.dart';
import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';

class NewsEsports extends StatefulWidget {
  @override
  _NewsEsportsState createState() => _NewsEsportsState();
}

class _NewsEsportsState extends State<NewsEsports> {

  final String texto = '     De streamer main Viper à "união de faculdades", o Brasil já conhece os times que brigam pelo título nacional do primeiro torneio mundial de VALORANT aos universitários. Após grandes embates, as equipes "Seleção", "Odin e Amigos" e "Stay at Home" garantiram vagas na semifinal do Red Bull Campus Clutch, que acontece dia 15 de maio e, agora, aguardam os próximos duelos. Entre os classificados, algumas curiosidades já chamam atenção dos fãs do fps. \n\n     Com mais de 127 mil seguidores na Twitch, Eduardo "Coreano" Pereira estuda na CEFET-MG. Em seus vídeos, mostra grande habilidade com a controladora Viper, sendo até elogiado por pro-players, casters e streamers do cenário brasileiro. Agora, pelo time Stay at Home, quer conquistar o título inédito do Red Bull Campus Clutch e representar o País no Mundial. \n\n     "Eu gostaria de jogar o Red Bull Campus Clutch com pessoas do cenário com as quais eu já tive certo contato. Todos os quatro jogadores do time (Docks, Prince, Rhamurthi e Suave) são jogadores que eu diariamente enfrentava nas filas ranqueadas do VALORANT, portanto, eu já conhecia o potencial individual de cada um. Depois de alguns contatos e conversas, resolvemos nos juntar para formar esse time para o campeonato. O Prince, em específico, já foi meu teammate em outros times não universitários de VALORANT, no passado", afirma Coreano. \n\n     Com cinco gamers de universidades diferentes, Seleção faz jus ao nome. Acostumados a disputar as ranqueadas de VALORANT, eles se uniram para formar um time focado no Mundial. Até o momento, a semifinal já está garantida. De vários cantos do Brasil, os estudantes da Seleção representam as faculdades UNIFAE, Mackenzie, IFF, IBMEC e Universidade Vila Velha. Já Odin e Amigos carregam a pluralidade em seus cursos, com representantes que variam de Educação Física, Nutrição até Direito. O nome do time homenageia a habilidade de um dos gamers, que costuma jogar com Odin.';

  @override
  Widget build(BuildContext context) {
    return Scaffold(

      appBar: AppBar(
        title: Text('ALLGAMES',
        style: GoogleFonts.lato(
          textStyle: TextStyle(color: Colors.white, fontSize: 24, fontWeight: FontWeight.bold)
        ),
        ),
        backgroundColor: Theme.of(context).primaryColor,
        automaticallyImplyLeading: false,
        actions: [
          IconButton(
            icon: Icon (
              Icons.close,
              color: Colors.white,
            ),
            onPressed: (){
              setState(() {
                Navigator.pop(context);
              });
            } )
        ],
        leading: Image.asset('assets/logo.png'), 
      ),

      body: SingleChildScrollView(

        child: Column(children: [

          NewsBody('Torneio mundial inédito aos universitários anuncia semifinalistas brasileiros', 'esports.png', texto),


        ],),

      ),

    );
      
  }
}