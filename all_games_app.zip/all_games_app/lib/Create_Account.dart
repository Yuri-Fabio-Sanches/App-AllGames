import 'package:flutter/material.dart';
import 'Widgets.dart';

class CreateAccount extends StatefulWidget {
  @override
  _CreateAccountState createState() => _CreateAccountState();
}

class _CreateAccountState extends State<CreateAccount> {
  //Atributos

  //Armazenar os valores digitados nos campos
  var txtNomeController = TextEditingController();
  var txtPasswordController = TextEditingController();
  var txtEmailController = TextEditingController();
  var txtDataNascimentoController = TextEditingController();
  var txtPasswordConfirmationController = TextEditingController();
  var txtEmailConfirmationController = TextEditingController();

  //chave que identifica unicamente o formulário
  var formKey = GlobalKey<FormState>();

  @override
  Widget build(BuildContext context) {
    return Scaffold(

      backgroundColor: Theme.of(context).backgroundColor,

      body: Container(
        padding: EdgeInsets.fromLTRB(40, 120, 40, 40),
        child: Form(
          key: formKey,
          child: Column(children: [
            Icon(Icons.person_add,
                size: 100, color: Theme.of(context).primaryColor),
            campoTexto('Nome','Entre com seu nome', txtNomeController),
            campoTexto('Email','Entre com seu email', txtEmailController),
            campoTexto('Confirmar email','Comfirme seu email', txtEmailConfirmationController),
            campoTexto('Senha','Entre com sua senha', txtPasswordConfirmationController),
            campoTexto('Confirmar senha','Confirme sua senha', txtPasswordController),
            campoTexto('Data de Nascimento','Entre com sua data de nascimento', txtDataNascimentoController),
            botaoCadastrar('Confirmar', context),
          ]),
        ),
      ),

    );
  }

  //
  // BOTÃO DE CADASTRO
  //
  Widget botaoCadastrar(rotulo, context) {
    return Container(
      padding: EdgeInsets.only(top: 40),
      width: 200,
      height: 80,
      child: ElevatedButton(
        style: ElevatedButton.styleFrom(primary: Theme.of(context).primaryColor),
          child: Text(
            rotulo,
            style: TextStyle(color: Colors.white, fontSize: 18),
          ),
          
          onPressed: () {

            setState(() {

                caixaDialogo('Conta cadastrada com sucesso.');
              });
            
          }),
    );
  }

  //
  // CAIXA DE DIÁLOGO
  //
  caixaDialogo(msg) {
    return showDialog(
        context: context,
        builder: (BuildContext context) {
          return AlertDialog(
            title: Text('Prontinho !'),
            content: Text(msg),
            actions: [
              TextButton(
                child: Text('Avançar'),
                onPressed: () {
                  Navigator.pushNamed(context, '/Login_Screen');
                },
              )
            ],
          );
        });
  }

}