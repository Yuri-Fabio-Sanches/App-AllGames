import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import 'Widgets.dart';

class NewsPromotion extends StatefulWidget {
  @override
  _NewsPromotionState createState() => _NewsPromotionState();
}

class _NewsPromotionState extends State<NewsPromotion> {

  final String texto = '     A oferta de jogos gratuitos na PS Plus mudará em 4 de maio, quando entram no catálogo os games Wreckfest: Drive Hard, Die Last, exclusivo para o PlayStation 5, e Battlefield 5 e Stranded Deep, para o PS4. Assinantes do serviço online devem adicionar os títulos à biblioteca até 31 de maio, antes da próxima rotação de jogos. \n\n     Lançado em junho 2018 no Steam, Wreckfest é um jogo de corrida, mas a diversão vai além de cruzar a linha de chegada: é possível destruir os veículos adversários no decorrer da prova. O modo multiplayer online também coloca os jogadores na mesma arena até que o último sobreviva. \n\n     Também de 2018, Battlefield 5 é o 16º título da franquia de tiro em primeira pessoa, que, dessa vez, retorna à história da Segunda Guerra Mundial em diferentes modos de jogo: solo, cooperativos ou no formato de battle royale. \n\n     De janeiro de 2015, Stranded Deep é um jogo de sobrevivência em primeira pessoa e com um mundo aberto. Na trama, o protagonista se vê em uma queda de avião no meio do Oceano Pacífico. Com isso, deve explorar terra e mar para encontrar recursos que garantam a perseverança diante das ameaças — sejam elas do cenário ou necessidades do personagem.';

  @override
  Widget build(BuildContext context) {
    return Scaffold(

      appBar: AppBar(
        title: Text('ALLGAMES',
        style: GoogleFonts.lato(
          textStyle: TextStyle(color: Colors.white, fontSize: 24, fontWeight: FontWeight.bold)
        ),
        ),
        backgroundColor: Theme.of(context).primaryColor,
        automaticallyImplyLeading: false,
        actions: [
          IconButton(
            icon: Icon (
              Icons.close,
              color: Colors.white,
            ),
            onPressed: (){
              setState(() {
                Navigator.pop(context);
              });
            } )
        ],
        leading: Image.asset('assets/logo.png'), 
      ),

      body: SingleChildScrollView(

        child: Column(children: [

          NewsBody('PS Plus de maio tem Wreckfest no PS5 e Battlefield 5 no PS4', 'promocao.png', texto),


        ],),

      ),

    );
      
  }
}