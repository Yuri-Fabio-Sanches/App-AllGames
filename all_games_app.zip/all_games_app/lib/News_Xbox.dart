import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import 'Widgets.dart';

class NewsXbox extends StatefulWidget {
  @override
  _NewsXboxState createState() => _NewsXboxState();
}

class _NewsXboxState extends State<NewsXbox> {

  final String texto = '     Se você tem um Xbox One, ou já está na nova geração com os Xbox Series S e X, é bom dar uma olhada na loja oficial de games para a plataforma da Microsoft. Por lá títulos como FIFA 21, Battlefield V e até Gears 5 estão custando consideravelmente menos, com descontos chegando até 85% para algumas dezenas de títulos. \n\n     Promoção é literalmente a melhor coisa para o público gamer brasileiro que já sofre tanto com os preços altos para os jogos de qualquer plataforma - oi Nintendo, você apela né. Para aliviar a jogatina, selecionamos 40 jogos do Xbox que estão em promoção até às 13h do dia 4 de maio, no horário de Brasília. \n\n     O principal nome desta lista é FIFA 21 e ele não precisa de qualquer introdução, mas me chamou atenção a presença de diversos títulos da série Battlefield, com nomes recentes como Battlefield V e Battlefield 1 Revolution. Enquanto o primeiro da dupla exibe narrativas rondando a Segunda Guerra Mundial, o segundo foca nas batalhas do conflito anterior. O desconto para os dois jogos é de 80%. \n\n     Gears 5 é o mais recente título da franquia exclusiva de tiro em terceira pessoa para os Xbox One e Series. Ele recebeu desconto de 60%, mas você também pode comprar com preço mais camarada o Gears Of War: Ultimate Edition Deluxe Version, que entrega gráficos aprimorados para o primeiro game da série - lançado originalmente para o Xbox 360 em 2006.'; 

  @override
  Widget build(BuildContext context) {
    return Scaffold(

      appBar: AppBar(
        title: Text('ALLGAMES',
        style: GoogleFonts.lato(
          textStyle: TextStyle(color: Colors.white, fontSize: 24, fontWeight: FontWeight.bold)
        ),
        ),
        backgroundColor: Theme.of(context).primaryColor,
        automaticallyImplyLeading: false,
        actions: [
          IconButton(
            icon: Icon (
              Icons.close,
              color: Colors.white,
            ),
            onPressed: (){
              setState(() {
                Navigator.pop(context);
              });
            } )
        ],
        leading: Image.asset('assets/logo.png'), 
      ),

      body: SingleChildScrollView(

        child: Column(children: [

          NewsBody('Xbox tem promoção de FIFA 21 e mais jogos com até 85% de desconto', 'xbox.png', texto),


        ],),

      ),

    );
      
  }
}