import 'package:flutter/material.dart';

  //
  // CAMPO DE TEXTO para entrada de dados
  //
  Widget campoTexto(rotulo, hintText, variavelControle) {
    return Container(
        padding: EdgeInsets.symmetric(vertical: 5),
        child: TextFormField(
          //Associar a variável ao campo de texto
          controller: variavelControle,
          style: TextStyle(fontSize: 24),
          decoration: InputDecoration(
            labelText: rotulo,
            hintText: hintText,
            hintStyle: TextStyle(fontSize: 18),
          ),

        ));
  }

  //
  // BOTÃO
  //
  Widget botao(rotulo, context, screen) {
    return Container(
      padding: EdgeInsets.only(top: 20),
      width: 200,
      height: 80,
      child: ElevatedButton(
        style: ElevatedButton.styleFrom(primary: Theme.of(context).primaryColor),
          child: Text(
            rotulo,
            style: TextStyle(color: Colors.white, fontSize: 18),
          ),
          
          onPressed: () {
            
            
            Navigator.pushNamed(context, screen);
            
          }),
    );
  }

//
//NEWS WIDGET
//
 class NewsWidget extends StatelessWidget {

  final String titulo;
  final String foto;
  final String rota;

  NewsWidget(this.titulo,this.foto, this.rota): super();

   @override
   Widget build(BuildContext context) {
     return InkWell(

       child: Container(

        width: double.infinity,
      //margin: EdgeInsets.all(20),
      //margin: EdgeInsets.symmetric(horizontal: 20),
      //margin: EdgeInsets.symmetric(vertical: 20),
      margin: EdgeInsets.fromLTRB(30,20,30,0),
      padding: EdgeInsets.fromLTRB(30, 20, 30, 20),
      alignment: Alignment.center,

      //bordas
      decoration: BoxDecoration(
        border: Border.all(color: Colors.deepPurple[800], width: 2),
        // color: Colors.deepPurple[100],
        borderRadius: BorderRadius.all(Radius.circular(10)),
        // gradient: LinearGradient(
        //   colors: [Colors.deepPurple[400], Colors.deepPurple[100]],
        //   begin: Alignment.topCenter,
        //   end: Alignment.bottomCenter
        // )
      ),

      
      child: Center(child: Column(children: <Widget> [

        Container(
          padding: EdgeInsets.fromLTRB(0, 0, 0, 15),
          child: Column(children: [
            ClipRRect(
              borderRadius: BorderRadius.circular(10),
              child: Image.asset(foto),
          )
          ],),
        ),

        Container(
          child: Column(children: [
            Text(titulo,style: TextStyle(fontSize: 20, fontWeight: FontWeight.bold), textAlign: TextAlign.center),
          ],)
        ),

      ],),), 

  ),

       onTap: (){
         Navigator.pushNamed(context, rota);
       },
       
     );
   }
 }

 //
 //News BODY
 //
 
 class NewsBody extends StatelessWidget {

  final String titulo;
  final String foto;
  final String texto;

  NewsBody(this.titulo,this.foto, this.texto): super();

   @override
   Widget build(BuildContext context) {
     return Container(

      width: double.infinity,
      margin: EdgeInsets.fromLTRB(30,20,30,0),
      padding: EdgeInsets.fromLTRB(30, 20, 30, 20),

      child: Center(child: Column(children: <Widget> [

        Container(
          child: Column(children: [
            Text(titulo,style: TextStyle(fontSize: 20, fontWeight: FontWeight.bold), textAlign: TextAlign.center),
          ],)
        ),

        Container(
          padding: EdgeInsets.fromLTRB(0, 20, 0, 20),
          child: Column(children: [
            ClipRRect(
              borderRadius: BorderRadius.circular(10),
              child: Image.asset(foto),
          )
          ],),
        ),
        
        Container(
          child: Column(children: [
            Text(texto,style: TextStyle(fontSize: 20), textAlign: TextAlign.justify,),
          ],)
        ),

      ],),), 
     );

   }
 }