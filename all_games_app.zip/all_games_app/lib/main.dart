import 'package:all_games_app/Create_Account.dart';
import 'package:flutter/material.dart';
import 'package:splashscreen/splashscreen.dart';
import 'Login_screen.dart';
import 'Home_Screen.dart';
import 'Create_Account.dart';
import 'Info_Screen.dart';
import 'News_ps5.dart';
import 'News_Xbox.dart';
import 'News_Promotion.dart';
import 'News_Esports.dart';

void main() => runApp(MyApp());

class MyApp extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      title: 'Splash Screen',
      theme: ThemeData(
      primaryColor: Colors.deepPurple[600],
      backgroundColor: Colors.white,
      fontFamily: 'Roboto',
      textTheme: TextTheme(
          headline1: TextStyle(fontSize: 18, color: Colors.white),),
    ),
      initialRoute: '/Splash_Screen',
      routes: {
        '/Splash_Screen': (context) => MyHomePage(),
        '/Login_Screen': (context) => LoginScreen(),
        '/Home_Screen': (context) => HomeScreen(),
        '/Create_Account': (context) => CreateAccount(),
        '/Info_Screen': (context) => InfoScreen(),
        '/News_Ps5': (context) => NewsPs5(),
        '/News_Xbox': (context) => NewsXbox(),
        '/News_Promotion': (context) => NewsPromotion(),
        '/News_Esports': (context) => NewsEsports(),
      },
    );
  }
}

class MyHomePage extends StatefulWidget {
  MyHomePage({Key key, this.title}) : super(key: key);
  final String title;

  @override
  _MyHomePageState createState() => _MyHomePageState();
}

class _MyHomePageState extends State<MyHomePage> {
  @override
  Widget build(BuildContext context) {
    return _introScreen();
  }
}

Widget _introScreen() {
  return Stack(
    children: <Widget>[
      SplashScreen(
        seconds: 3,
        backgroundColor: Colors.deepPurple[600],
        navigateAfterSeconds: LoginScreen(),
        loaderColor: Colors.transparent,
      ),
      Container(
        decoration: BoxDecoration(
          image: DecorationImage(
            image: AssetImage("assets/logo.png"),
            fit: BoxFit.none,
          ),
        ),
      ),
    ],
  );
}