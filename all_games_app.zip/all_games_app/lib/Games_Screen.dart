import 'package:flutter/material.dart';

class GamesScreen extends StatefulWidget {
  @override
  _GamesScreenState createState() => _GamesScreenState();
}

class _GamesScreenState extends State<GamesScreen> {

  var jogosSeguindo = [];
  var jogosNaoSeguindo = [];
  var logosSeguindoJogos = [];
  var logosNaoSeguindoJogos = [];

  // var txttimesSeguindo = TextEditingController();
  // var txttimesNaoSeguindo = TextEditingController();

  @override
  void initState(){
    logosSeguindoJogos.add(AssetImage("assets/LOL.png"),);
    logosSeguindoJogos.add(AssetImage("assets/R6.jpg"),);
    logosSeguindoJogos.add(AssetImage("assets/FreeFire.png"),);
    logosSeguindoJogos.add(AssetImage("assets/Dota2.png"),);
    logosSeguindoJogos.add(AssetImage("assets/CSGO.png"),);

    logosNaoSeguindoJogos.add(AssetImage("assets/Rocket.jpg"),);
    logosNaoSeguindoJogos.add(AssetImage("assets/Clash.png"),);
    logosNaoSeguindoJogos.add(AssetImage("assets/FIFA.png"),);
    logosNaoSeguindoJogos.add(AssetImage("assets/Overwatch.png"),);
    logosNaoSeguindoJogos.add(AssetImage("assets/Fortinite.png"),);

    jogosSeguindo.add("League of Legends");
    jogosSeguindo.add("Rainbow Six Siege");
    jogosSeguindo.add("Free Fire");
    jogosSeguindo.add("Dota 2");
    jogosSeguindo.add("Counter-Strike Global Offensive");

    jogosNaoSeguindo.add("Rocket League");
    jogosNaoSeguindo.add("Clash of Clans");
    jogosNaoSeguindo.add("FIFA 2021");
    jogosNaoSeguindo.add("Overwatch");
    jogosNaoSeguindo.add("Fortnite");
    super.initState();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Container(
        padding: EdgeInsets.all(40),

        child:Column(
          children: [

            Container(
              padding: EdgeInsets.fromLTRB(0, 0, 0, 10),
              child: Column(children: [Text('Jogos favoritos',style: TextStyle(fontSize: 20, fontWeight: FontWeight.bold, color: Colors.deepPurple[600]), textAlign: TextAlign.center)],),
            ),

            SizedBox(height: 30),

            Expanded(
              child: ListView.separated(

                //aparência item
                itemBuilder: (context, index){
                  return Container(
                    child: ListTile(
                      leading: CircleAvatar(backgroundImage: logosSeguindoJogos[index], backgroundColor: Colors.white,),
                      title: Text(jogosSeguindo[index]),
                      subtitle: Text('Seguindo'),
                      trailing: Icon(Icons.check_circle_outline, color: Colors.green), 
                      )
                    );
                },

                //aprencia separador
                separatorBuilder: (context, index){
                  return Divider(
                    color: Theme.of(context).primaryColor,
                    thickness: 1,
                  );
                },

                //quantidade itens
                itemCount: jogosSeguindo.length,

              )
            ),

            Container(
              padding: EdgeInsets.fromLTRB(0, 40, 0, 30),
              child: Column(children: [Text('Seguir novos jogos',style: TextStyle(fontSize: 20, fontWeight: FontWeight.bold, color: Colors.deepPurple[600]), textAlign: TextAlign.center)],),
            ),

            Expanded(
              child: ListView.separated(

                //aparência item
                itemBuilder: (context, index){
                  return Container(
                    child: ListTile(
                      leading: CircleAvatar(backgroundImage: logosNaoSeguindoJogos[index], backgroundColor: Colors.white,),
                      title: Text(jogosNaoSeguindo[index]),
                      subtitle: Text('Não seguindo'),
                      trailing: Icon(Icons.highlight_off, color: Colors.red),
                      )
                    );
                },

                //aprencia separador
                separatorBuilder: (context, index){
                  return Divider(
                    color: Theme.of(context).primaryColor,
                    thickness: 1,
                  );
                },

                //quantidade itens
                itemCount: jogosNaoSeguindo.length,

              )
            )

          ],
        ),
      ),
    );
  }
}