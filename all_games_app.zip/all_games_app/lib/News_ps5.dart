import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import 'Widgets.dart';

class NewsPs5 extends StatefulWidget {
  @override
  _NewsPs5State createState() => _NewsPs5State();
}

class _NewsPs5State extends State<NewsPs5> {

  final String texto = '     O PlayStatation 5 está vendendo mais rápido que o PlayStation 4, segundo o relatório financeiro da Sony, divulgado nesta quarta-feira (28). De acordo com o documento, 7,8 milhões de unidades do PS5 foram comercializadas entre novembro de 2020 e o final de março deste ano. Em comparação, a empresa entregou 7,6 milhões de PS4 nesse mesmo intervalo de tempo na época do lançamento, entre 2013 e 2014. \n\n     Além do número de consoles vendidos, a empresa também informou que o PS Plus teve 47,6 milhões de assinantes no final de março, 14,7% a mais que no mesmo mês do ano passado. Com esses resultados, a divisão PlayStation rendeu à Sony 3,1 bilhões de dolares (cerca de 16,7 bilhões de reais) no ano fiscal de 2020, batendo o recorde de lucro anual. \n\n     O relatório financeiro da Sony mostra que, dos 7,8 milhões de PS5 vendidos, 4,5 milhões de unidades foram comercializadas nos últimos dois meses do ano passado e 3,3 milhões nos primeiros três meses deste ano. A média de vendas por mês diminuiu do ano passado para cá devido à alta procura pelo console. \n\n     A Sony previa vender 7,6 milhões de PS5 até o final do ano fiscal de 2020. Porém, a demanda pela console foi maior, e a Sony não conseguiu fabricar novos aparelhos na mesma velocidade. Segundo o presidente da Sony Interactive Entertainment, Jim Ryan, os estoques do PS5 devem melhorar no segundo semestre. Quando a produção normalizar, a média de consoles vendidos mensalmente deve aumentar novamente.';

  @override
  Widget build(BuildContext context) {
    return Scaffold(

      appBar: AppBar(
        title: Text('ALLGAMES',
        style: GoogleFonts.lato(
          textStyle: TextStyle(color: Colors.white, fontSize: 24, fontWeight: FontWeight.bold)
        ),
        ),
        backgroundColor: Theme.of(context).primaryColor,
        automaticallyImplyLeading: false,
        actions: [
          IconButton(
            icon: Icon (
              Icons.close,
              color: Colors.white,
            ),
            onPressed: (){
              setState(() {
                Navigator.pop(context);
              });
            } )
        ],
        leading: Image.asset('assets/logo.png'), 
      ),

     body: SingleChildScrollView(

        child: Column(children: [

          NewsBody('PS5 vende mais rápido que PS4 e faz Sony bater recorde de lucro anual', 'ps5.png', texto),


        ],),

      ),

    );
      
  }
}