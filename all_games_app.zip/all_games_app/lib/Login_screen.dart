import 'package:flutter/material.dart';
import 'Widgets.dart';

class LoginScreen extends StatefulWidget {
  @override
  _LoginScreenState createState() => _LoginScreenState();
}

class _LoginScreenState extends State<LoginScreen> {
  //Atributos

  //Armazenar os valores digitados nos campos
  var txtEmailController = TextEditingController();
  var txtPasswordController = TextEditingController();

  //chave que identifica unicamente o formulário
  var formKey = GlobalKey<FormState>();

  @override
  Widget build(BuildContext context) {
    return Scaffold(

      /*appBar: AppBar(
        title: Text('Login',
        style: Theme.of(context).textTheme.headline1,
        ),
        backgroundColor: Theme.of(context).primaryColor,
        centerTitle: true, 
      ),*/

      backgroundColor: Theme.of(context).backgroundColor,

      body: Container(
        padding: EdgeInsets.fromLTRB(40, 120, 40, 40),
        child: Form(
          key: formKey,
          child: Column(children: [
            Icon(Icons.perm_identity,
                size: 100, color: Theme.of(context).primaryColor),
            campoTexto('Email','Entre com seu email', txtEmailController),
            campoTexto('Senha','Entre com sua senha', txtPasswordController),
            botao('Entrar', context, '/Home_Screen'),
            botao('Cadastrar', context, '/Create_Account'),
          ]),
        ),
      ),

    );
  }

}

  
